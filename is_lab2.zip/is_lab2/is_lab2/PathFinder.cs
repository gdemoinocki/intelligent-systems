﻿using is_lab2;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;


public static class PathFinder
{
    public static List<Path> FindPaths(Maze maze, Point start, Point end, int maxDepth = 100)
    {
        List<Path> paths = new List<Path>();
        Queue<Path> queue = new Queue<Path>();
        queue.Enqueue(new Path(new List<Point> { start })); 

        while (queue.Count > 0)
        {
            Path currentPath = queue.Dequeue();
            Point currentCell = currentPath.Steps.Last();

            if (currentCell.Equals(end))
            {
                paths.Add(currentPath);
            }
            if (currentPath.Steps.Count < maxDepth)
            {
                var neighbors = GetNeighbors(maze, currentCell);
                foreach (var neighbor in neighbors)
                {
                    if (!currentPath.Steps.Contains(neighbor))
                    {
                        List<Point> newSteps = new List<Point>(currentPath.Steps);
                        newSteps.Add(neighbor);
                        queue.Enqueue(new Path(newSteps)); // Исправлено: передаем newSteps
                    }
                }
            }

        }
        return paths;
    }

    public static List<Path> FindPaths(Maze maze, Point start, Point end)
    {
        return FindPaths(maze, start, end, 100);
    }

    private static IEnumerable<Point> GetNeighbors(Maze maze, Point current)
    {
        int[][] directions = {
            new[] { 0, 1 },
            new[] { 0, -1 },
            new[] { 1, 0 },
            new[] { -1, 0 }
         };
        foreach (var dir in directions)
        {
            int newX = current.X + dir[0];
            int newY = current.Y + dir[1];
            var cell = maze.GetCell(newX, newY);
            if (cell != null && cell.Type != CellType.Wall)
            {
                yield return new Point(newX, newY);
            }
        }
    }
}