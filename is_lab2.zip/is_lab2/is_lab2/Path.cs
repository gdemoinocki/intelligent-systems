﻿using System.Collections.Generic;
using System.Drawing;

public class Path
{
    public List<Point> Steps { get; set; }
    public int Length => Steps.Count;

    public Path(List<Point> steps)
    {
        Steps = steps;
    }
}