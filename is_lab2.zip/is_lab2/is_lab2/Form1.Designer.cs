﻿namespace is_lab2
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.mazePictureBox = new System.Windows.Forms.PictureBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.loadButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.wallRadioButton = new System.Windows.Forms.RadioButton();
            this.emptyRadioButton = new System.Windows.Forms.RadioButton();
            this.startRadioButton = new System.Windows.Forms.RadioButton();
            this.exitRadioButton = new System.Windows.Forms.RadioButton();
            this.pathsListBox = new System.Windows.Forms.ListBox();
            this.pathLengthLabel = new System.Windows.Forms.Label();
            this.allPathsListBox = new System.Windows.Forms.ListBox();
            this.findPathButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.mazePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // mazePictureBox
            // 
            this.mazePictureBox.Location = new System.Drawing.Point(12, 12);
            this.mazePictureBox.Name = "mazePictureBox";
            this.mazePictureBox.Size = new System.Drawing.Size(499, 416);
            this.mazePictureBox.TabIndex = 0;
            this.mazePictureBox.TabStop = false;
            this.mazePictureBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.mazePictureBox_MouseClick);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.AliceBlue;
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saveButton.Location = new System.Drawing.Point(783, 26);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(144, 44);
            this.saveButton.TabIndex = 1;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // loadButton
            // 
            this.loadButton.BackColor = System.Drawing.Color.AliceBlue;
            this.loadButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loadButton.Location = new System.Drawing.Point(783, 76);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(144, 48);
            this.loadButton.TabIndex = 2;
            this.loadButton.Text = "Загрузить";
            this.loadButton.UseVisualStyleBackColor = false;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.Color.AliceBlue;
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clearButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clearButton.Location = new System.Drawing.Point(783, 128);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(144, 43);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Очистить";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // wallRadioButton
            // 
            this.wallRadioButton.AutoSize = true;
            this.wallRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.wallRadioButton.Location = new System.Drawing.Point(550, 39);
            this.wallRadioButton.Name = "wallRadioButton";
            this.wallRadioButton.Size = new System.Drawing.Size(193, 24);
            this.wallRadioButton.TabIndex = 4;
            this.wallRadioButton.TabStop = true;
            this.wallRadioButton.Text = "Нарисовать стенку";
            this.wallRadioButton.UseVisualStyleBackColor = true;
            this.wallRadioButton.CheckedChanged += new System.EventHandler(this.wallRadioButton_CheckedChanged);
            // 
            // emptyRadioButton
            // 
            this.emptyRadioButton.AutoSize = true;
            this.emptyRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.emptyRadioButton.Location = new System.Drawing.Point(550, 80);
            this.emptyRadioButton.Name = "emptyRadioButton";
            this.emptyRadioButton.Size = new System.Drawing.Size(197, 24);
            this.emptyRadioButton.TabIndex = 5;
            this.emptyRadioButton.TabStop = true;
            this.emptyRadioButton.Text = "Нарисовать проход";
            this.emptyRadioButton.UseVisualStyleBackColor = true;
            this.emptyRadioButton.CheckedChanged += new System.EventHandler(this.emptyRadioButton_CheckedChanged);
            // 
            // startRadioButton
            // 
            this.startRadioButton.AutoSize = true;
            this.startRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.startRadioButton.Location = new System.Drawing.Point(550, 128);
            this.startRadioButton.Name = "startRadioButton";
            this.startRadioButton.Size = new System.Drawing.Size(177, 24);
            this.startRadioButton.TabIndex = 6;
            this.startRadioButton.TabStop = true;
            this.startRadioButton.Text = "Нарисовать вход";
            this.startRadioButton.UseVisualStyleBackColor = true;
            this.startRadioButton.CheckedChanged += new System.EventHandler(this.startRadioButton_CheckedChanged);
            // 
            // exitRadioButton
            // 
            this.exitRadioButton.AutoSize = true;
            this.exitRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exitRadioButton.Location = new System.Drawing.Point(550, 174);
            this.exitRadioButton.Name = "exitRadioButton";
            this.exitRadioButton.Size = new System.Drawing.Size(189, 24);
            this.exitRadioButton.TabIndex = 7;
            this.exitRadioButton.TabStop = true;
            this.exitRadioButton.Text = "Нарисовать выход";
            this.exitRadioButton.UseVisualStyleBackColor = true;
            this.exitRadioButton.CheckedChanged += new System.EventHandler(this.exitRadioButton_CheckedChanged);
            // 
            // pathsListBox
            // 
            this.pathsListBox.FormattingEnabled = true;
            this.pathsListBox.ItemHeight = 16;
            this.pathsListBox.Location = new System.Drawing.Point(550, 264);
            this.pathsListBox.Name = "pathsListBox";
            this.pathsListBox.Size = new System.Drawing.Size(197, 212);
            this.pathsListBox.TabIndex = 8;
            this.pathsListBox.SelectedIndexChanged += new System.EventHandler(this.pathsListBox_SelectedIndexChanged);
            // 
            // pathLengthLabel
            // 
            this.pathLengthLabel.AutoSize = true;
            this.pathLengthLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pathLengthLabel.Location = new System.Drawing.Point(547, 231);
            this.pathLengthLabel.Name = "pathLengthLabel";
            this.pathLengthLabel.Size = new System.Drawing.Size(220, 20);
            this.pathLengthLabel.TabIndex = 9;
            this.pathLengthLabel.Text = "Длинна выбранного пути";
            // 
            // allPathsListBox
            // 
            this.allPathsListBox.FormattingEnabled = true;
            this.allPathsListBox.ItemHeight = 16;
            this.allPathsListBox.Location = new System.Drawing.Point(753, 264);
            this.allPathsListBox.Name = "allPathsListBox";
            this.allPathsListBox.Size = new System.Drawing.Size(197, 212);
            this.allPathsListBox.TabIndex = 10;
            this.pathsListBox.SelectedIndexChanged += new System.EventHandler(this.allPathsListBox_SelectedIndexChanged);
            // 
            // findPathButton
            // 
            this.findPathButton.BackColor = System.Drawing.Color.AliceBlue;
            this.findPathButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findPathButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.findPathButton.Location = new System.Drawing.Point(783, 177);
            this.findPathButton.Name = "findPathButton";
            this.findPathButton.Size = new System.Drawing.Size(144, 43);
            this.findPathButton.TabIndex = 11;
            this.findPathButton.Text = "Найти путь ";
            this.findPathButton.UseVisualStyleBackColor = false;
            this.findPathButton.Click += new System.EventHandler(this.findPathButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 599);
            this.Controls.Add(this.findPathButton);
            this.Controls.Add(this.allPathsListBox);
            this.Controls.Add(this.pathLengthLabel);
            this.Controls.Add(this.pathsListBox);
            this.Controls.Add(this.exitRadioButton);
            this.Controls.Add(this.startRadioButton);
            this.Controls.Add(this.emptyRadioButton);
            this.Controls.Add(this.wallRadioButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.loadButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.mazePictureBox);
            this.Name = "MainForm";
            this.Text = "ИС Lab №2 Лабиринт";
            ((System.ComponentModel.ISupportInitialize)(this.mazePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox mazePictureBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.RadioButton wallRadioButton;
        private System.Windows.Forms.RadioButton emptyRadioButton;
        private System.Windows.Forms.RadioButton startRadioButton;
        private System.Windows.Forms.RadioButton exitRadioButton;
        private System.Windows.Forms.ListBox pathsListBox;
        private System.Windows.Forms.Label pathLengthLabel;
        private System.Windows.Forms.ListBox allPathsListBox;
        private System.Windows.Forms.Button findPathButton;
    }
}

