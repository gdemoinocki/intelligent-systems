﻿public enum CellType { Empty, Wall, Start, Exit }

public class Cell
{
    public CellType Type { get; set; }
    public int X { get; set; }
    public int Y { get; set; }

    public Cell(int x, int y, CellType type = CellType.Empty)
    {
        X = x;
        Y = y;
        Type = type;
    }
}
