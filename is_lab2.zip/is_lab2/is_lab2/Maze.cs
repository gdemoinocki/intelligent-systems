﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;

public class Maze
{
    public List<Cell> Cells { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public int CellSize { get; set; }

    public Point StartPosition { get; set; }
    public List<Point> ExitPositions { get; set; } = new List<Point>();


    public Maze(int width, int height, int cellSize)
    {
        Width = width;
        Height = height;
        CellSize = cellSize;
        Cells = new List<Cell>();
        for (int y = 0; y < Height; y++)
        {
            for (int x = 0; x < Width; x++)
            {
                Cells.Add(new Cell(x, y));
            }
        }
    }

    public Cell GetCell(int x, int y)
    {
        return Cells.FirstOrDefault(c => c.X == x && c.Y == y);
    }

    public void SetCellType(int x, int y, CellType type)
    {
        var cell = GetCell(x, y);
        if (cell == null) return;
        cell.Type = type;

        if (type == CellType.Start)
        {
            StartPosition = new Point(x, y);
        }
        else if (type == CellType.Exit)
        {
            if (ExitPositions.Count < 3)
                ExitPositions.Add(new Point(x, y));
        }
    }

    public void Draw(Graphics g)
    {
        foreach (var cell in Cells)
        {
            Color color;
            switch (cell.Type)
            {
                case CellType.Wall:
                    color = Color.Black;
                    break;
                case CellType.Start:
                    color = Color.Green;
                    break;
                case CellType.Exit:
                    color = Color.Red;
                    break;
                default:
                    color = Color.White;
                    break;
            }

            g.FillRectangle(new SolidBrush(color), cell.X * CellSize, cell.Y * CellSize, CellSize, CellSize);
            g.DrawRectangle(Pens.Gray, cell.X * CellSize, cell.Y * CellSize, CellSize, CellSize);
        }
    }
    public void ClearMaze()
    {
        foreach (var cell in Cells)
        {
            cell.Type = CellType.Empty;
        }
        StartPosition = Point.Empty;
        ExitPositions.Clear();
    }

    public void SaveToFile(string filePath)
    {
        using (var writer = new StreamWriter(filePath))
        {
            writer.WriteLine($"{Width},{Height},{CellSize}");
            writer.WriteLine($"{StartPosition.X},{StartPosition.Y}");
            writer.WriteLine(string.Join(";", ExitPositions.Select(p => $"{p.X},{p.Y}")));

            foreach (var cell in Cells)
            {
                writer.WriteLine($"{cell.X},{cell.Y},{(int)cell.Type}");
            }
        }
    }

    public static Maze LoadFromFile(string filePath)
    {
        using (var reader = new StreamReader(filePath))
        {
            var dimensions = reader.ReadLine().Split(',');
            int width = int.Parse(dimensions[0]);
            int height = int.Parse(dimensions[1]);
            int cellSize = int.Parse(dimensions[2]);

            var maze = new Maze(width, height, cellSize);

            var startPos = reader.ReadLine().Split(',');
            int startX = int.Parse(startPos[0]);
            int startY = int.Parse(startPos[1]);
            maze.SetCellType(startX, startY, CellType.Start);

            var exitPositions = reader.ReadLine().Split(';');
            foreach (var exitPosition in exitPositions)
            {
                if (string.IsNullOrEmpty(exitPosition)) continue;

                var exitPos = exitPosition.Split(',');
                int exitX = int.Parse(exitPos[0]);
                int exitY = int.Parse(exitPos[1]);
                maze.SetCellType(exitX, exitY, CellType.Exit);
            }

            while (!reader.EndOfStream)
            {
                var cellData = reader.ReadLine().Split(',');
                int x = int.Parse(cellData[0]);
                int y = int.Parse(cellData[1]);
                CellType type = (CellType)int.Parse(cellData[2]);
                maze.SetCellType(x, y, type);
            }
            return maze;
        }
    }
}