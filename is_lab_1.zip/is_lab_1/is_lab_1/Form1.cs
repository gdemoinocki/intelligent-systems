﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace is_lab_1
{
    public partial class Form1 : Form
    {
        // Поля класса для хранения данных и состояния
        private int _rows; // Количество строк шахматной доски
        private int _cols; // Количество столбцов шахматной доски
        private int _startX; // Начальная позиция коня по X
        private int _startY; // Начальная позиция коня по Y
        private int[,] _board; // Двумерный массив для представления шахматной доски, -1 = пустая, иначе номер хода
        private Button[,] _boardButtons; // Двумерный массив кнопок для отображения доски на форме
        private bool _tourFound = false; // Флаг, указывающий, был ли найден обход
        private const int MaxRecursionDepth = 10000; // Максимальная глубина рекурсии, чтобы избежать бесконечных циклов
        public Form1()
        {
            InitializeComponent();
        }

        // Обработчик нажатия кнопки "Start"
        private async void startButton_Click(object sender, EventArgs e)
        {
            ClearBoard(); // Очищаем доску перед новым расчетом

            // Получаем размеры доски и начальные координаты из текстовых полей, проверяем на корректность ввода
            if (!int.TryParse(rowsTextBox.Text, out _rows) ||
                !int.TryParse(colsTextBox.Text, out _cols) ||
                !int.TryParse(startXTextBox.Text, out _startX) ||
                !int.TryParse(startYTextBox.Text, out _startY))
            {
                MessageBox.Show("Пожалуйста, введите корректные значения для размеров доски и начальной позиции.");
                return;
            }
            if ( (_rows < 3 && _cols < 4) || (_rows < 4 && _cols < 3))
            {
                MessageBox.Show("Обход доски возможен только на доске с полями 3х4, 4х3 или любой доской больше 4х4");
                return;
            }
            else if (_rows == 3 && _cols == 3) 
            {
                MessageBox.Show("Обход доски возможен только на доске с полями 3х4, 4х3 или любой доской больше 4х4");
                return;
            }
            else if (_rows == 4 && _cols == 4)
            {
                MessageBox.Show("Обход доски возможен только на доске с полями 3х4, 4х3 или любой доской больше 4х4");
                return;
            }



            // Проверяем допустимость размеров доски и начальных координат
            if (_rows <= 0 || _cols <= 0 || _startX < 0 || _startX >= _cols || _startY < 0 || _startY >= _rows)
            {
                MessageBox.Show("Недопустимые значения размеров или начальной позиции.");
                return;
            }

            // Инициализируем массив доски и массив кнопок

            _board = new int[_rows, _cols];
            _boardButtons = new Button[_rows, _cols];
            CreateChessBoard(); // Создаем визуальное представление шахматной доски

            // Запускаем вычисления в отдельном потоке, чтобы не блокировать UI
            await Task.Run(() =>
            {
                Game game = new Game(_rows, _cols); // Создаем экземпляр класса Game
                _tourFound = game.KnightTour(_startY, _startX); // Пытаемся найти обход конем с помощью алгоритма из класса Game
                _board = game.desk; // Получаем результат обхода

                if (!_tourFound)
                {
                    MessageBox.Show("Невозможно обойти доску конем с заданной начальной позиции.", "Ошибка");
                    //ClearBoard(); // Если обход не найден, очищаем доску
                }
                else
                {
                    UpdateBoardUI(); // Если обход найден, обновляем UI
                    HighlightStartAndEnd(); // Выделяем начальную и конечную позиции
                }
            });
        }

        // Создание визуального представления доски на форме
        private void CreateChessBoard()
        {
            boardPanel.Controls.Clear(); // Очищаем панель
            boardPanel.ColumnStyles.Clear(); // Очищаем стили столбцов
            boardPanel.RowStyles.Clear();  // Очищаем стили строк
            boardPanel.ColumnCount = _cols;  // Задаем количество столбцов в таблице
            boardPanel.RowCount = _rows;   // Задаем количество строк в таблице

            // Вычисляем размер кнопки, чтобы поместиться в панель
            int buttonSize = Math.Min(
                boardPanel.ClientSize.Width / _cols,
                boardPanel.ClientSize.Height / _rows
            );

            // Создаем кнопки для каждой клетки доски
            for (int row = 0; row < _rows; row++)
            {
                boardPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, buttonSize)); // Устанавливаем высоту строки
                for (int col = 0; col < _cols; col++)
                {
                    if (row == 0)
                        boardPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, buttonSize)); // Устанавливаем ширину столбца

                    var btn = new Button(); // Создаем новую кнопку
                    btn.Text = ""; // Текст кнопки пуст
                    btn.Size = new Size(buttonSize, buttonSize); // Задаем размер кнопки
                    btn.BackColor = (row + col) % 2 == 0 ? Color.WhiteSmoke : Color.LightGray; // Устанавливаем цвет фона
                    btn.Margin = Padding.Empty; // Убираем отступы
                    btn.FlatStyle = FlatStyle.Flat; // Убираем рамку
                    btn.FlatAppearance.BorderSize = 0; // Убираем границу

                    boardPanel.Controls.Add(btn, col, row); // Добавляем кнопку в таблицу
                    _boardButtons[row, col] = btn; // Сохраняем кнопку в массиве кнопок
                }
            }
        }
        //Очистка шахматной доски
        private void ClearBoard()
        {
            if (_boardButtons == null)
                return; // Если кнопки не созданы, то ничего не делаем

            foreach (Button button in _boardButtons)
                button.Dispose(); // Удаляем все кнопки

            boardPanel.Controls.Clear(); // Очищаем панель
            boardPanel.ColumnStyles.Clear(); // Очищаем стили столбцов
            boardPanel.RowStyles.Clear(); // Очищаем стили строк
        }
        // Обновляет визуальное представление шахматной доски на форме
        private void UpdateBoardUI()
        {
            // Проверяем, вызов произошел в UI потоке
            if (InvokeRequired)
            {
                // Если нет, вызываем этот же метод в UI потоке
                Invoke(new Action(UpdateBoardUI));
            }
            else
            {
                // Обновляем текст каждой кнопки на доске
                for (int row = 0; row < _rows; row++)
                {
                    for (int col = 0; col < _cols; col++)
                    {
                        _boardButtons[row, col].Text = (_board[row, col] == 0) ? "" : (_board[row, col]).ToString();
                    }
                }
            }
        }
        // Метод для выделения начальной и конечной позиций коня
        private void HighlightStartAndEnd()
        {
            // Проверяем, вызов произошел в UI потоке
            if (InvokeRequired)
            {
                // Если нет, вызываем этот же метод в UI потоке
                Invoke(new Action(HighlightStartAndEnd));
            }
            else
            {
                _boardButtons[_startY, _startX].BackColor = Color.Red; // Выделяем начальную позицию красным

                // Ищем конечную позицию (последний ход)
                int endX = -1;
                int endY = -1;

                for (int row = 0; row < _rows; row++)
                {
                    for (int col = 0; col < _cols; col++)
                    {
                        if (_board[row, col] == _rows * _cols)
                        {
                            endX = col;
                            endY = row;
                            break;
                        }
                    }
                    if (endX != -1)
                        break;
                }
                // Выделяем конечную позицию зеленым
                if (endX != -1 && endY != -1)
                    _boardButtons[endY, endX].BackColor = Color.Green;
            }
        }
    }

    // Класс Game для обхода конем
    public class Game
    {
        // Поля класса для хранения данных и состояния
        public int n; // Счетчик ходов
        public int[,] desk; // Двумерный массив для представления шахматной доски, где хранятся шаги обхода
        // Массив шагов коня
        public int[,] step = new int[8, 2] { { 1, -2 }, { 2, -1 }, { 2, 1 }, { 1, 2 }, { -1, 2 }, { -2, 1 }, { -2, -1 }, { -1, -2 } };

        // Конструктор класса, инициализирует доску
        public Game(int x, int y)
        {
            desk = new int[x, y];
        }

        // Метод для поиска обхода конем
        public bool KnightTour(int x, int y)
        {
            // Проверка на выход за границы доски
            if (x < 0 || x >= desk.GetLength(0) || y < 0 || y >= desk.GetLength(1))
                return false;

            // Проверка, что клетка еще не посещена
            if (desk[x, y] != 0)
                return false;
            // Увеличиваем счетчик ходов и помечаем клетку как посещенную
            n++;
            desk[x, y] = n;

            // Если все клетки посещены, то возвращаем true
            if (n == desk.Length)
            {
                return true;
            }
            // Получаем список возможных следующих ходов
            List<(int, int)> nextMoves = GetNextMoves(x, y);
            // Сортируем ходы по возрастанию доступных клеток
            nextMoves.Sort((a, b) =>
            {
                int countA = CountAccessibleCells(a.Item1, a.Item2);
                int countB = CountAccessibleCells(b.Item1, b.Item2);
                return countA.CompareTo(countB);
            });
            // Пытаемся сделать каждый из ходов
            foreach (var (nextX, nextY) in nextMoves)
            {
                if (KnightTour(nextX, nextY))
                {
                    return true;
                }
            }
            // Если ни один из ходов не привел к решению, то отменяем ход и возвращаем false
            n--;
            desk[x, y] = 0;

            return false;
        }
        // Метод для получения возможных следующих ходов коня
        private List<(int, int)> GetNextMoves(int x, int y)
        {
            List<(int, int)> moves = new List<(int, int)>();
            // Проходим по всем возможным ходам коня
            for (int i = 0; i < 8; i++)
            {
                int nextX = x + step[i, 0];
                int nextY = y + step[i, 1];
                // Проверяем, что ход в пределах доски и клетка не посещена
                if (nextX >= 0 && nextX < desk.GetLength(0) && nextY >= 0 && nextY < desk.GetLength(1) && desk[nextX, nextY] == 0)
                {
                    moves.Add((nextX, nextY));
                }
            }

            return moves;
        }
        // Метод для подсчета количества доступных клеток из заданной клетки
        private int CountAccessibleCells(int x, int y)
        {
            int count = 0;
            // Проходим по всем возможным ходам коня
            for (int i = 0; i < 8; i++)
            {
                int nextX = x + step[i, 0];
                int nextY = y + step[i, 1];
                // Проверяем, что ход в пределах доски и клетка не посещена
                if (nextX >= 0 && nextX < desk.GetLength(0) && nextY >= 0 && nextY < desk.GetLength(1) && desk[nextX, nextY] == 0)
                {
                    count++;
                }
            }

            return count;
        }
    }
}